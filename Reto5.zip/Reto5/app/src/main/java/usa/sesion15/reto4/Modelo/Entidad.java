package usa.sesion15.reto4.Modelo;

import android.net.Uri;

public class Entidad {

    Uri imagen;
    String descripcion1, descripcion2, descripcion3;

    public Entidad(Uri imagen, String descripcion1, String descripcion2, String descripcion3) {
        this.imagen = imagen;
        this.descripcion1 = descripcion1;
        this.descripcion2 = descripcion2;
        this.descripcion3 = descripcion3;
    }

    public Uri getImagen() {
        return imagen;
    }

    public String getDescripcion1() {
        return descripcion1;
    }
    public String getDescripcion2() {
        return descripcion2;
    }

    public String getDescripcion3() {
        return descripcion3;
    }
}
