package usa.sesion15.reto4.Vista;

import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.net.Uri;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ListView;
import android.widget.TextView;

import androidx.fragment.app.Fragment;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;

import reto4.R;
import usa.sesion15.reto4.Modelo.Adaptador;
import usa.sesion15.reto4.Modelo.BaseDatos.MotorBaseDatosSQLite;
import usa.sesion15.reto4.Modelo.Entidad;

public class Fragment_Productos extends Fragment {

    View v;
    ListView listaProductos;
    Adaptador adaptador;
    Uri imageUri1, imageUri2, imageUri3;
    TextView prueba;
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        v = inflater.inflate(R.layout.fragment__productos, container, false);
        //-----------------------------------------------------------------------------
        listaProductos = (ListView) v.findViewById(R.id.lista_productos);
        adaptador = new Adaptador(GetListItems(), getContext());

        listaProductos.setAdapter(adaptador);
        prueba = (TextView) v.findViewById(R.id.prueba);


        //-----------------------------------------------------------------------------
        return v;
    }

    private ArrayList<Entidad> GetListItems(){

        /*//imageUri1 = Uri.parse("android.resource://" + getContext().getPackageName() + "/" + R.drawable.producto1);
        //imageUri2 = Uri.parse("android.resource://" + getContext().getPackageName() + "/" + R.drawable.producto3);
        //imageUri3 = Uri.parse("android.resource://" + getContext().getPackageName() + "/" + R.drawable.producto2);
        ArrayList<Entidad> listaItems = new ArrayList<>();
        // CONEXION A LA BASE DE DATOS: SQLite
        MotorBaseDatosSQLite conector = new MotorBaseDatosSQLite(getContext(),"bdMyJacketShop", null, 1);
        SQLiteDatabase db_leer = conector.getReadableDatabase();
        conector.onUpgrade(db_leer, 1, 2);
        Cursor cursor = db_leer.rawQuery("SELECT * FROM productos", null);


        while(cursor.moveToNext()){
            listaItems.add(new Entidad(Uri.parse(cursor.getString(0)), cursor.getString(1), cursor.getString(2), cursor.getString(3)));
        }

        //listaItems.add(new Entidad(imageUri1, "Marca: AlpinStar", "Colores: Blanco, negro y azul","Material: Cuero y Lino"));
        //listaItems.add(new Entidad(imageUri2, "Marca: Chevignon", "Colores: Negro y blanco","Material: Cuero"));
        //listaItems.add(new Entidad(imageUri3, "Marca: GirBaud", "Colores: Verde, azul, rosa","Material: Lino")); */
        ArrayList<Entidad> listaItems = new ArrayList<>();
        String url = "https://g15e132c41bfdba-ciclo4.adb.sa-santiago-1.oraclecloudapps.com/ords/admin/productos/productos";


        RequestQueue requestQueue = Volley.newRequestQueue(getContext());

        JsonObjectRequest jsonObjectRequest = new JsonObjectRequest(Request.Method.GET, url, null, new Response.Listener<JSONObject>() {
            @Override
            public void onResponse(JSONObject response) {
                //***********************************************************
                try {
                    JSONArray jsonArray = response.getJSONArray("items");
                    for(int i = 0; i < jsonArray.length(); i++){
                        JSONObject jsonObject = jsonArray.getJSONObject(i);


                        String img = jsonObject.getString("img");
                        String descripcion1 = jsonObject.getString("descripcion1");
                        String descripcion2 = jsonObject.getString("descripcion2");
                        String descripcion3 = jsonObject.getString("descripcion3");

                        listaItems.add(new Entidad(Uri.parse(img), descripcion1, descripcion2, descripcion3));
                        prueba.append(" " + '\n');

                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                }
                //***********************************************************
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                error.printStackTrace();
            }
        });

        requestQueue.add(jsonObjectRequest);
        /* ================================================================================================== */

        return listaItems;
    }
}