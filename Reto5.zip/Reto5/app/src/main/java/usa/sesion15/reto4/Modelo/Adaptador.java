package usa.sesion15.reto4.Modelo;

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;

import reto4.R;
import usa.sesion15.reto4.Modelo.BaseDatos.MotorBaseDatosSQLite;

public class Adaptador extends BaseAdapter{

    ArrayList<Entidad> lista_items;
    Context context;

    public Adaptador(ArrayList<Entidad> lista_items, Context context) {
        this.lista_items = lista_items;
        this.context = context;
    }

    @Override
    public int getCount() {
        return lista_items.size(); // Devuelve cuntos elementos hay en la lista
    }

    @Override
    public Object getItem(int posicion) {
        return lista_items.get(posicion); // devuelve la posicion del item
    }

    @Override
    public long getItemId(int posicion) {
        return 0; // No lo vamos a trabajar
    }

    /*
    Este es el metodo mas importante, aqui vamos a asignar el item y lo elementos y valores a
    cada item.
     */
    @Override
    public View getView(int posicion, View v, ViewGroup viewGroup) {

        Entidad datosItem = (Entidad) getItem(posicion);

        v = LayoutInflater.from(context).inflate(R.layout.item, null);
        //-------------------------------------------------------------------

        ImageView imagen = (ImageView) v.findViewById(R.id.imagen01);
        TextView descripcion1 = (TextView) v.findViewById(R.id.textView11);
        TextView descripcion2 = (TextView) v.findViewById(R.id.textView12);
        TextView descripcion3 = (TextView) v.findViewById(R.id.textView13);
        Button boton1 = (Button) v.findViewById(R.id.botoninfo);
        Button botonMapa = (Button) v.findViewById(R.id.botonmapa);
        CheckBox favoritos = (CheckBox) v.findViewById(R.id.favoritos_item);

        /*
        Pongo los datos de cada item desde la clase Entidad dentro de cada elemento xml
         */
        imagen.setImageURI(datosItem.getImagen());
        descripcion1.setText(datosItem.getDescripcion1());
        descripcion2.setText(datosItem.getDescripcion2());
        descripcion3.setText(datosItem.getDescripcion3());

        //----------------------------------------------------------------
        MotorBaseDatosSQLite conectar = new MotorBaseDatosSQLite(context, "bdMyJacketShop", null, 1);
        ;
        SQLiteDatabase db_escribir = conectar.getWritableDatabase();

        String string1 = descripcion1.getText().toString();
        String string2 = descripcion2.getText().toString();
        String string3 = descripcion3.getText().toString();
        String stringCursor = "";

        if (string1.equals("Marca: AlpinStar") || string1.equals("Marca: Chevignon") || string1.equals("Marca: GirBaud")) {
            stringCursor = "SELECT * FROM productos WHERE descripcion1 = '" + string1 + "'";
        } else if (string1.equals("Domicilios") || string1.equals("Estampado") || string1.equals("Confección")) {
            stringCursor = "SELECT * FROM servicios WHERE descripcion1 = '" + string1 + "'";
        } else if (string1.equals("Sucursal Central") || string1.equals("Sucursal Alterna 1") || string1.equals("Sucursal Alterna 2")) {
            stringCursor = "SELECT * FROM sucursales WHERE descripcion1 = '" + string1 + "'";
        }
        //String stringCursor = "SELECT * FROM productos WHERE descripcion1 = '" + string1 + "'";
        Cursor cursor = db_escribir.rawQuery(stringCursor, null);
        cursor.moveToFirst();
        String stringImg = cursor.getString(0);

        //String sqlAdd = "INSERT INTO favoritos VALUES ('android.resource://usa.sesion15.reto4/2131165287', 'Domicilios','Sin costo de envío','Pagos contraentrega')";
        //System.out.println(stringImg);
        //System.out.println(string1);
        //System.out.println(string2);
        //System.out.println(string3);
        String sqlAdd = "INSERT INTO favoritos VALUES ('"+stringImg+"', '"+string1+"','"+string2+"','"+string3+"')";
        String sqlDel = "DELETE FROM favoritos WHERE descripcion1 = '" + string1 + "'";


        //-------------------------------------------------------------------------------------------------
        v.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(context, "Funcionalidad en próximas versiones :-)", Toast.LENGTH_LONG ).show();
            }
        });

        boton1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(favoritos.isChecked()){
                    db_escribir.execSQL(sqlDel);
                    db_escribir.execSQL(sqlAdd);
                    Toast.makeText(context, "Agregado a favoritos!!!", Toast.LENGTH_LONG).show();
                }else{
                    db_escribir.execSQL(sqlDel);
                    Toast.makeText(context, "Eliminado de favoritos!!! \n Check para AGREGAR", Toast.LENGTH_LONG).show();

                }

            }
        });

        //-------------------------------------------------------------------
        return v;
    }

}
