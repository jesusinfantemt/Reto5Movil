package usa.sesion15.reto4.Controlador;

import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentTransaction;

import reto4.R;
import usa.sesion15.reto4.Vista.Fragment_Favoritos;
import usa.sesion15.reto4.Vista.Fragment_Inicio;
import usa.sesion15.reto4.Vista.Fragment_Mapa;
import usa.sesion15.reto4.Vista.Fragment_Productos;
import usa.sesion15.reto4.Vista.Fragment_Servicios;
import usa.sesion15.reto4.Vista.Fragment_Sucursales;

public class MainActivity extends AppCompatActivity{
    Fragment subPantalla1, subPantalla2, subPantalla3, subPantallaInicio, subPantallaFavoritos, subPantallaMapa;
    FragmentTransaction intercambio;

    Button boton1, botonMapa;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        subPantalla1 = new Fragment_Productos();
        subPantalla2 = new Fragment_Servicios();
        subPantalla3 = new Fragment_Sucursales();
        subPantallaInicio = new Fragment_Inicio();
        subPantallaFavoritos = new Fragment_Favoritos();
        subPantallaMapa = new Fragment_Mapa();

        getSupportFragmentManager().beginTransaction().add(R.id.contenedor_fragments, subPantallaInicio).commit();

        boton1 = (Button)findViewById(R.id.boton1);
        boton1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                View visible = findViewById(R.id.botonmapa);
                intercambio = getSupportFragmentManager().beginTransaction();
                intercambio.replace(R.id.contenedor_fragments, subPantallaInicio).commit();
                visible.setVisibility(View.GONE);

            }
        });


        botonMapa = (Button)findViewById(R.id.botonmapa);
        botonMapa.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                intercambio = getSupportFragmentManager().beginTransaction();
                intercambio.replace(R.id.contenedor_fragments, subPantallaMapa).commit();
                intercambio.addToBackStack(null);
            }
        });


    }
    //****************************************** MENU DE OPCIONES ***************************************************
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.menuopciones, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        View visible = findViewById(R.id.botonmapa);
        int id = item.getItemId();
        if (id == R.id.opcion1){
            intercambio = getSupportFragmentManager().beginTransaction();
            intercambio.replace(R.id.contenedor_fragments, subPantalla1).commit();
            intercambio.addToBackStack(null);
            visible.setVisibility(View.GONE);

        }
        if (id == R.id.opcion2){
            intercambio = getSupportFragmentManager().beginTransaction();
            intercambio.replace(R.id.contenedor_fragments, subPantalla2).commit();
            intercambio.addToBackStack(null);
            visible.setVisibility(View.GONE);
        }
        if (id == R.id.opcion3){
            intercambio = getSupportFragmentManager().beginTransaction();
            intercambio.replace(R.id.contenedor_fragments, subPantalla3).commit();
            intercambio.addToBackStack(null);

            botonMapa.setVisibility(View.VISIBLE);

        }
        if (id == R.id.opcion4){
            intercambio = getSupportFragmentManager().beginTransaction();
            intercambio.replace(R.id.contenedor_fragments,subPantallaFavoritos).commit();
            intercambio.addToBackStack(null);
            visible.setVisibility(View.GONE);
        }
        return super.onOptionsItemSelected(item);
    }
    //*****************************************************************************************************************
}